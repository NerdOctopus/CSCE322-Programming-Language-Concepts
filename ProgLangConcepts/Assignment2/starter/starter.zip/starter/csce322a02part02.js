module.exports = {
    onePlayerManyMoves: onePlayerManyMoves
}

var helpers = require( './helpers' );

function onePlayerManyMoves( game ){
    
    function whatever( moves ){
	return game;
    }

    return whatever;
}
