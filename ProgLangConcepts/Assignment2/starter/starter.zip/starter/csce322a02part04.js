module.exports = {
    manyPlayersManyMoves: manyPlayersManyMoves
}

var helpers = require( './helpers' );

function manyPlayersManyMoves( game ){
    
    function whatever( moves ){
	return game;
    }

    return whatever;
}
