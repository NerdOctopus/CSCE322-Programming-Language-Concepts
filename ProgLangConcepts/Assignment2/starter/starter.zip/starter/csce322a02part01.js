module.exports = {
    onePlayerOneMove: onePlayerOneMove
}

var helpers = require( './helpers' );

function onePlayerOneMove( game ){
    
    function whatever( move ){
	return game;
    }

    return whatever;
}
