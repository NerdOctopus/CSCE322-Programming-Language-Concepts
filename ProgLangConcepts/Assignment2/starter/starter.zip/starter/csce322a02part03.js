module.exports = {
    manyPlayersOneMove: manyPlayersOneMove
}

var helpers = require( './helpers' );

function manyPlayersOneMove( game ){
    
    function whatever( moves ){
	return game;
    }

    return whatever;
}
