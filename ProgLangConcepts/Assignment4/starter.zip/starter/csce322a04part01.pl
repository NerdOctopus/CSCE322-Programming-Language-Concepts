columnsAndRows(Game).
