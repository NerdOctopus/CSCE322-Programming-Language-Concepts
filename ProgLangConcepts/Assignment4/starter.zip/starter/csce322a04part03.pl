fewestMoves(Game,[u,d]).
