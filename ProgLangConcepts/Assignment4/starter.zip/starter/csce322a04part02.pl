openSpaces(Game).
