noIslands(Game).
