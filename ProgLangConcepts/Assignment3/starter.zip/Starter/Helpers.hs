module Helpers
( readExtremePegSolitaireFile
, printGame
, countPlayers
) where

import Prelude
import Data.Char
import Data.List
import Debug.Trace

readExtremePegSolitaireFile :: String -> IO ([[Char]],[Char])
readExtremePegSolitaireFile = readIO

printGame :: [[Char]] -> IO ()
printGame [] = do
	       print ""
printGame (row:rows) = do
	  	       print row
		       printGame rows

countPlayers :: [[Char]] -> Int
countPlayers game = (length game) * (length (head game)) - numSpaces - numPegs
	     where numSpaces = length (find2D game '-')
	     	   numPegs   = length (find2D game 'x')

find2D :: [[Char]] -> Char -> [(Int,Int)]
find2D [] _ = []
find2D (row:rows) e = first ++ rest
       where first = [(0,c)|c<-(find1D row e)]
       	     rest  = [(r+1,c)|(r,c)<-(find2D rows e)]

find1D :: [Char] -> Char -> [Int]
find1D [] _ = []
find1D (h:t) e
       | h == e		= 0:rst
       | otherwise	= rst
       where rest = find1D t e
       	     rst  = map (+ 1) rest